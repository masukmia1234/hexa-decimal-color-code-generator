const hex=document.querySelector(".hex");
const btn=document.querySelector(".generate");


const generateColor=()=>{
  const randomcolor=Math.random().toString(16).substring(2,8);
  document.body.style.backgroundColor="#"+randomcolor;
  hex.innerHTML="#"+randomcolor;
};
btn.addEventListener("click",generateColor);
generateColor();